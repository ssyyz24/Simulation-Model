import os
from pathlib import Path

import numpy as np
import pandas as pd


# =========================
# Helper functions
# =========================

def _read_csv_if_exists(path: str) -> pd.DataFrame | None:
    p = Path(path)
    if not p.exists():
        return None
    return pd.read_csv(p)

def _fmt(x, nd=2):
    if x is None or (isinstance(x, float) and (np.isnan(x) or np.isinf(x))):
        return "NA"
    return f"{x:.{nd}f}"

def _pick_quantiles(df: pd.DataFrame | None, value_col: str) -> tuple[float | None, float | None]:
    """
    Expected format:
      quantile, <value_col>
      P50, ...
      P95, ...
    """
    if df is None or df.empty:
        return None, None

    qcol = "quantile" if "quantile" in df.columns else None
    if qcol is None or value_col not in df.columns:
        return None, None

    def get_q(qname):
        rows = df[df[qcol].astype(str).str.upper() == qname]
        if rows.empty:
            return None
        v = rows.iloc[0][value_col]
        try:
            return float(v)
        except Exception:
            return None

    return get_q("P50"), get_q("P95")

def _overall_abandon_rate_from_riders(riders_path: str) -> float | None:
    df = _read_csv_if_exists(riders_path)
    if df is None or df.empty:
        return None

    status_col = "status_group" if "status_group" in df.columns else ("status" if "status" in df.columns else None)
    if status_col is None:
        return None

    total = len(df)
    if total == 0:
        return None

    abandoned = (df[status_col].astype(str).str.lower() == "abandoned").sum()
    return abandoned / total

def _mean_rate_from_lambda_csv(df: pd.DataFrame | None) -> float | None:
    """
    Accepts lambda_r_15min.csv style:
      may contain a 'rate_per_hour' column
    """
    if df is None or df.empty:
        return None
    if "rate_per_hour" in df.columns:
        return float(df["rate_per_hour"].mean())
    if "mean_count" in df.columns:
        return float((df["mean_count"] / 0.25).mean())
    return None


# =========================
# Inputs (expected filenames)
# =========================

RIDERS_CLEAN = "riders_clean.csv"
DRIVERS_CLEAN = "drivers_clean.csv"

LAMBDA_R = "lambda_r_15min.csv"
LAMBDA_D = "lambda_d_15min.csv"

OD_MATRIX = "OD_matrix_5x5.csv"

TRIP_Q = "trip_hours_quantiles.csv"
ONLINE_Q = "online_hours_quantiles.csv"

ABANDON_BY_BIN = "abandon_rate_by_bin.csv"


# =========================
# Load optional calibration artifacts
# =========================

lambda_r_df = _read_csv_if_exists(LAMBDA_R)
lambda_d_df = _read_csv_if_exists(LAMBDA_D)

trip_q_df = _read_csv_if_exists(TRIP_Q)
online_q_df = _read_csv_if_exists(ONLINE_Q)

od_df = _read_csv_if_exists(OD_MATRIX)
abandon_bin_df = _read_csv_if_exists(ABANDON_BY_BIN)

# Extract summary values
lambda_r_mean = _mean_rate_from_lambda_csv(lambda_r_df)
lambda_d_mean = _mean_rate_from_lambda_csv(lambda_d_df)

trip_p50, trip_p95 = _pick_quantiles(trip_q_df, "trip_hours")
online_p50, online_p95 = _pick_quantiles(online_q_df, "online_hours")

abandon_overall = _overall_abandon_rate_from_riders(RIDERS_CLEAN)

# Decide OD option text
od_option_text = (
    "Option A (recommended): sample OD zone-pair from \\texttt{OD\\_matrix\\_5x5.csv}, "
    "then sample points within zones"
)

# If the OD matrix file is missing, fall back to a joint resample statement
if od_df is None:
    od_option_text = (
        "Option B: joint resample historical OD quadruples (pickup \\& dropoff together) "
        "from cleaned trips"
    )

# Abandon-by-bin availability
abandon_by_bin_text = "Abandonment-by-bin target from \\texttt{abandon\\_rate\\_by\\_bin.csv}"
if abandon_bin_df is None:
    abandon_by_bin_text = "Abandonment-by-bin target: NA (file not found)"


# =========================
# Build LaTeX table (TabularX)
# =========================

# Keep the main table compact; details remain in CSV files or the appendix.
rows = [
    ("\\textbf{Demand \\& supply}", "", "", ""),
    ("Rider arrivals $\\lambda_r(t)$",
     f"Piecewise Poisson (15-min bins), mean $\\bar\\lambda_r\\approx$ {_fmt(lambda_r_mean, 2)}",
     "requests/hour",
     f"\\texttt{{{LAMBDA_R}}}" if lambda_r_df is not None else "\\texttt{lambda\\_r\\_15min.csv} (NA)"),

    ("Driver logins $\\lambda_d(t)$",
     f"Piecewise Poisson (15-min bins), mean $\\bar\\lambda_d\\approx$ {_fmt(lambda_d_mean, 2)}",
     "drivers/hour",
     f"\\texttt{{{LAMBDA_D}}}" if lambda_d_df is not None else "\\texttt{lambda\\_d\\_15min.csv} (NA)"),

    ("\\textbf{Spatial}", "", "", ""),
    ("Location generation",
     od_option_text,
     "zones/coords",
     f"\\texttt{{{OD_MATRIX}}}" if od_df is not None else "\\texttt{(empirical OD resample)}"),

    ("\\textbf{Service time}", "", "", ""),
    ("Trip duration",
     f"Empirical sampling (ECDF). P50={_fmt(trip_p50, 2)} h, P95={_fmt(trip_p95, 2)} h",
     "hours",
     "\\texttt{trip\\_hours\\_empirical.csv}"),

    ("\\textbf{Driver availability}", "", "", ""),
    ("Driver online duration",
     f"Empirical sampling (ECDF). P50={_fmt(online_p50, 2)} h, P95={_fmt(online_p95, 2)} h",
     "hours",
     "\\texttt{online\\_hours\\_empirical.csv}"),

    ("\\textbf{Cancellation}", "", "", ""),
    ("Overall abandonment rate",
     f"{_fmt(abandon_overall, 3)}",
     "probability",
     f"\\texttt{{{RIDERS_CLEAN}}}"),

    ("Abandonment rate by time-of-day",
     abandon_by_bin_text,
     "rate",
     f"\\texttt{{{ABANDON_BY_BIN}}}" if abandon_bin_df is not None else "\\texttt{(NA)}"),
]

latex = []
latex.append(r"\begin{table}[H]")
latex.append(r"\centering")
latex.append(r"\caption{Final calibrated inputs used in the simulation (summary)}")
latex.append(r"\label{tab:final_calibrated_inputs}")
latex.append(r"\begin{tabularx}{\textwidth}{l X l l}")
latex.append(r"\toprule")
latex.append(r"\textbf{Component} & \textbf{Distribution / value (summary)} & \textbf{Units} & \textbf{Data source} \\")
latex.append(r"\midrule")

for comp, distval, units, source in rows:
    if comp.startswith(r"\textbf"):
        latex.append(r"\addlinespace")
        latex.append(f"{comp} &  &  & \\\\")
        latex.append(r"\addlinespace")
    else:
        latex.append(f"{comp} & {distval} & {units} & {source} \\\\")

latex.append(r"\bottomrule")
latex.append(r"\end{tabularx}")
latex.append(r"\end{table}")

latex_str = "\n".join(latex)

# Write to file
OUT_TEX = "table_1_final_calibrated_inputs.tex"
with open(OUT_TEX, "w", encoding="utf-8") as f:
    f.write(latex_str)

print("Saved:", OUT_TEX)
print("\n" + latex_str)