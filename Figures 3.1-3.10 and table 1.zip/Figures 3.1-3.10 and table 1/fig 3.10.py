import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# =========================
# Configuration
# =========================

INPUT_FILE = "riders_clean.csv"

FIG_OUTPUT = "fig_3_10_abandon_by_bin.png"
CSV_OUTPUT = "abandon_rate_by_bin.csv"

BIN_MINUTES = 15
BINS_PER_DAY = 24 * 60 // BIN_MINUTES   # 96 bins

# Optional smoothing window (set to 1 to disable)
SMOOTH_WINDOW = 1


# =========================
# Load data
# =========================

df = pd.read_csv(INPUT_FILE)

# Detect request time column
if "request_datetime" in df.columns:
    time_col = "request_datetime"
elif "request_time" in df.columns:
    time_col = "request_time"
else:
    raise ValueError("No request_datetime or request_time column found.")

df[time_col] = pd.to_datetime(df[time_col], errors="coerce")
df = df.dropna(subset=[time_col])


# Detect status column
if "status_group" in df.columns:
    status_col = "status_group"
elif "status" in df.columns:
    status_col = "status"
else:
    raise ValueError("No status_group or status column found.")


# Identify abandoned requests
df["is_abandoned"] = df[status_col].astype(str).str.lower() == "abandoned"


# =========================
# Create time-of-day bins
# =========================

minutes = df[time_col].dt.hour * 60 + df[time_col].dt.minute
df["bin"] = (minutes // BIN_MINUTES).astype(int)

df = df[(df["bin"] >= 0) & (df["bin"] < BINS_PER_DAY)]


# =========================
# Compute abandonment rate
# =========================

grouped = df.groupby("bin")

total_requests = grouped.size().rename("total_requests")
abandoned_requests = grouped["is_abandoned"].sum().rename("abandoned_requests")

summary = pd.concat([total_requests, abandoned_requests], axis=1)
summary = summary.reindex(range(BINS_PER_DAY), fill_value=0)

summary["abandon_rate"] = np.where(
    summary["total_requests"] > 0,
    summary["abandoned_requests"] / summary["total_requests"],
    np.nan
)

# Export calibration data
output_df = summary.reset_index()[["bin", "abandon_rate", "total_requests"]]
output_df.to_csv(CSV_OUTPUT, index=False)

print("Saved:", CSV_OUTPUT)


# =========================
# Optional smoothing
# =========================

rate = summary["abandon_rate"]

if SMOOTH_WINDOW > 1:
    rate_smoothed = rate.rolling(SMOOTH_WINDOW, center=True, min_periods=1).mean()
else:
    rate_smoothed = rate


# =========================
# Plot figure
# =========================

x_hours = (np.arange(BINS_PER_DAY) * BIN_MINUTES) / 60

plt.figure(figsize=(10, 5))

plt.plot(x_hours, rate_smoothed)

plt.title("Fig 3.10 Abandonment rate by time of day (15-minute bins)")
plt.xlabel("Time of day (hours)")
plt.ylabel("Abandonment rate")

plt.xticks(np.arange(0, 25, 2))
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(FIG_OUTPUT, dpi=300)
plt.close()

print("Saved:", FIG_OUTPUT)