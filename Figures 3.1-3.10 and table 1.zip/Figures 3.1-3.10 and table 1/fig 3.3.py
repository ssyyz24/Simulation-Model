import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

# =========================
# Config
# =========================
INPUT = Path("riders_clean.csv")
FIG_OUT = Path("fig_3_3_pickup_heatmap.png")
CSV_OUT = Path("pickup_grid_counts.csv")

GRID_N = 50                 # 50x50 (can be changed to 40)
PLOT_COMPLETED_ONLY = False # True: use only dropped-off
EXPORT_GRID_COUNTS = True   # Export grid count table

# Squareshire area
X_MIN, X_MAX = 0.0, 20.0
Y_MIN, Y_MAX = 0.0, 20.0

# =========================
# Load
# =========================
df = pd.read_csv(INPUT)

required = {"pickup_x", "pickup_y"}
missing = required - set(df.columns)
if missing:
    raise ValueError(f"riders_clean.csv is missing columns: {missing}")

# Optional filter: completed only
if PLOT_COMPLETED_ONLY:
    if "status" not in df.columns:
        raise ValueError("Completed-only mode requires a status column.")
    df = df[df["status"] == "dropped-off"].copy()

# Keep valid coordinates in range
df["pickup_x"] = pd.to_numeric(df["pickup_x"], errors="coerce")
df["pickup_y"] = pd.to_numeric(df["pickup_y"], errors="coerce")
df = df.dropna(subset=["pickup_x", "pickup_y"]).copy()

df = df[
    df["pickup_x"].between(X_MIN, X_MAX) &
    df["pickup_y"].between(Y_MIN, Y_MAX)
].copy()

x = df["pickup_x"].values
y = df["pickup_y"].values

# =========================
# 2D histogram (counts)
# =========================
counts, xedges, yedges = np.histogram2d(
    x, y,
    bins=GRID_N,
    range=[[X_MIN, X_MAX], [Y_MIN, Y_MAX]]
)

# =========================
# Plot heatmap
# =========================
plt.figure(figsize=(6.5, 6))
# the array for imshow must be transposed, and origin='lower'
# is required to match the coordinate system
plt.imshow(
    counts.T,
    origin="lower",
    extent=[X_MIN, X_MAX, Y_MIN, Y_MAX],
    aspect="equal"
)
plt.colorbar(label="Pickup count per grid cell")

title_suffix = " (completed only)" if PLOT_COMPLETED_ONLY else " (all requests)"
plt.title(f"Fig 3.3 Spatial demand: pickup heatmap{title_suffix}")
plt.xlabel("x (miles)")
plt.ylabel("y (miles)")
plt.tight_layout()
plt.savefig(FIG_OUT, dpi=200)
plt.close()

print(f"[OK] Saved: {FIG_OUT.resolve()}")

# =========================
# Export grid counts 
# =========================
if EXPORT_GRID_COUNTS:
    # Generate center-point coordinates and counts for each grid cell
    x_centers = (xedges[:-1] + xedges[1:]) / 2
    y_centers = (yedges[:-1] + yedges[1:]) / 2

    rows = []
    for i, xc in enumerate(x_centers):
        for j, yc in enumerate(y_centers):
            rows.append({
                "grid_x_idx": i,
                "grid_y_idx": j,
                "x_center": float(xc),
                "y_center": float(yc),
                "count": int(counts[i, j]),
            })

    grid_df = pd.DataFrame(rows)
    grid_df.to_csv(CSV_OUT, index=False)
    print(f"[OK] Saved: {CSV_OUT.resolve()}")