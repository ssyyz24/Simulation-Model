import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# =====================
# Load data
# =====================
df = pd.read_csv("riders_clean.csv")

# Use completed trips only
df = df[df["status"] == "dropped-off"]

# Keep valid coordinates
df = df.dropna(subset=["dropoff_x", "dropoff_y"])

x = df["dropoff_x"]
y = df["dropoff_y"]

# =====================
# Heatmap grid
# =====================
GRID_SIZE = 50

heatmap, xedges, yedges = np.histogram2d(
    x,
    y,
    bins=GRID_SIZE,
    range=[[0,20],[0,20]]
)

# =====================
# Plot
# =====================
plt.figure(figsize=(6.5,6))

plt.imshow(
    heatmap.T,
    origin="lower",
    extent=[0,20,0,20],
    aspect="equal"
)

plt.colorbar(label="Dropoff count per grid cell")

plt.title("Fig 3.4 Spatial demand: dropoff heatmap")
plt.xlabel("x (miles)")
plt.ylabel("y (miles)")

plt.tight_layout()

plt.savefig("fig_3_4_dropoff_heatmap.png", dpi=300)

plt.close()

print("Fig 3.4 saved: fig_3_4_dropoff_heatmap.png")