import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ======================
# Config
# ======================

INPUT_FILE = "riders_clean.csv"

FIG_OUT = "fig_3_7_trip_hours_ecdf.png"
EMPIRICAL_OUT = "trip_hours_empirical.csv"
QUANTILE_OUT = "trip_hours_quantiles.csv"

# ======================
# Load data
# ======================

df = pd.read_csv(INPUT_FILE)

# Completed trips
df = df[df["status"] == "dropped-off"]

trip_hours = df["trip_hours"].dropna().values

# ======================
# ECDF
# ======================

x = np.sort(trip_hours)
y = np.arange(1, len(x) + 1) / len(x)

# ======================
# Quantiles
# ======================

q50 = np.quantile(trip_hours, 0.50)
q90 = np.quantile(trip_hours, 0.90)
q95 = np.quantile(trip_hours, 0.95)
q99 = np.quantile(trip_hours, 0.99)

quantile_df = pd.DataFrame({
    "quantile": ["P50", "P90", "P95", "P99"],
    "trip_hours": [q50, q90, q95, q99]
})

quantile_df.to_csv(QUANTILE_OUT, index=False)

print("Saved:", QUANTILE_OUT)

# ======================
# Save empirical sample
# ======================

empirical_df = pd.DataFrame({
    "trip_hours": trip_hours
})

empirical_df.to_csv(EMPIRICAL_OUT, index=False)

print("Saved:", EMPIRICAL_OUT)

# ======================
# Plot ECDF
# ======================

plt.figure(figsize=(7, 5))

plt.plot(x, y)

# Quantile lines
plt.axvline(q50, linestyle="--", linewidth=1)
plt.axvline(q95, linestyle="--", linewidth=1)

plt.text(q50, 0.5, "P50", rotation=90, va="bottom")
plt.text(q95, 0.5, "P95", rotation=90, va="bottom")

plt.title("Fig 3.7 Trip duration distribution (ECDF)")
plt.xlabel("Trip duration (hours)")
plt.ylabel("ECDF")

plt.grid(True, alpha=0.3)

plt.tight_layout()

plt.savefig(FIG_OUT, dpi=300)

plt.close()

print("Saved:", FIG_OUT)