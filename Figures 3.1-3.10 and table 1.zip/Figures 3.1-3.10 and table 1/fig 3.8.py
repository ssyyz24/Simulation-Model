import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ======================
# Config
# ======================

INPUT_FILE = "drivers_clean.csv"

FIG_OUT = "fig_3_8_online_hours_ecdf.png"
EMPIRICAL_OUT = "online_hours_empirical.csv"
QUANTILE_OUT = "online_hours_quantiles.csv"

# ======================
# Load data
# ======================

df = pd.read_csv(INPUT_FILE)

online_hours = df["online_hours"].dropna().values

# ======================
# ECDF calculation
# ======================

x = np.sort(online_hours)
y = np.arange(1, len(x) + 1) / len(x)

# ======================
# Quantiles
# ======================

q50 = np.quantile(online_hours, 0.50)
q90 = np.quantile(online_hours, 0.90)
q95 = np.quantile(online_hours, 0.95)
q99 = np.quantile(online_hours, 0.99)

quantile_df = pd.DataFrame({
    "quantile": ["P50", "P90", "P95", "P99"],
    "online_hours": [q50, q90, q95, q99]
})

quantile_df.to_csv(QUANTILE_OUT, index=False)

print("Saved:", QUANTILE_OUT)

# ======================
# Save empirical samples
# ======================

empirical_df = pd.DataFrame({
    "online_hours": online_hours
})

empirical_df.to_csv(EMPIRICAL_OUT, index=False)

print("Saved:", EMPIRICAL_OUT)

# ======================
# Plot ECDF
# ======================

plt.figure(figsize=(7, 5))

plt.plot(x, y)

# Quantile lines
plt.axvline(q50, linestyle="--", linewidth=1)
plt.axvline(q95, linestyle="--", linewidth=1)

plt.text(q50, 0.5, "P50", rotation=90, va="bottom")
plt.text(q95, 0.5, "P95", rotation=90, va="bottom")

plt.title("Fig 3.8 Driver online duration distribution (ECDF)")
plt.xlabel("Driver online duration (hours)")
plt.ylabel("ECDF")

plt.grid(True, alpha=0.3)

plt.tight_layout()

plt.savefig(FIG_OUT, dpi=300)

plt.close()

print("Saved:", FIG_OUT)