import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

# =========================
# Config
# =========================
INPUT = Path("drivers_clean.csv")
FIG_OUT = Path("fig_3_2_lambda_d.png")
CSV_OUT = Path("lambda_d_15min.csv")

BIN_MINUTES = 15
BINS_PER_DAY = 24 * 60 // BIN_MINUTES  # 96
PLOT_WEEKDAY_WEEKEND = True  # False: only plot all-days

# Appendix (optional): Poisson check Var/Mean by bin
MAKE_POISSON_CHECK = True
VOM_CSV_OUT = Path("var_over_mean_by_bin.csv")
VOM_FIG_OUT = Path("fig_A_1_var_over_mean.png")


# =========================
# Load
# =========================
df = pd.read_csv(INPUT)

if "arrival_datetime" not in df.columns:
    raise ValueError("Column 'arrival_datetime' not found in drivers_clean.csv.")

df["arrival_datetime"] = pd.to_datetime(df["arrival_datetime"], errors="coerce")
df = df.dropna(subset=["arrival_datetime"]).copy()

# Date + 15-min bin index (0..95)
df["date"] = df["arrival_datetime"].dt.date
minutes = df["arrival_datetime"].dt.hour * 60 + df["arrival_datetime"].dt.minute
df["bin"] = (minutes // BIN_MINUTES).astype(int)
df = df[(df["bin"] >= 0) & (df["bin"] < BINS_PER_DAY)].copy()


# =========================
# Helper: mean profile (across days)
# =========================
def mean_profile(sub: pd.DataFrame) -> pd.DataFrame:
    days = pd.Index(sorted(sub["date"].unique()))
    n_days = len(days)

    daily_bin = (
        sub.groupby(["date", "bin"])
        .size()
        .rename("count")
        .reset_index()
    )

    # Fill missing bins per day with 0
    full_index = pd.MultiIndex.from_product([days, range(BINS_PER_DAY)], names=["date", "bin"])
    daily_full = (
        daily_bin.set_index(["date", "bin"])
        .reindex(full_index, fill_value=0)
        .reset_index()
    )

    prof = (
        daily_full.groupby("bin")["count"]
        .mean()
        .rename("mean_count")
        .reset_index()
    )

    prof["start_minute"] = prof["bin"] * BIN_MINUTES
    prof["end_minute"] = (prof["bin"] + 1) * BIN_MINUTES
    prof["rate_per_hour"] = prof["mean_count"] / (BIN_MINUTES / 60.0)  # /0.25
    prof["n_days"] = n_days

    return prof[["bin", "start_minute", "end_minute", "mean_count", "rate_per_hour", "n_days"]]


# =========================
# Compute profiles
# =========================
profile_all = mean_profile(df)

if PLOT_WEEKDAY_WEEKEND:
    df["is_weekend"] = df["arrival_datetime"].dt.weekday >= 5
    profile_weekday = mean_profile(df[~df["is_weekend"]])
    profile_weekend = mean_profile(df[df["is_weekend"]])

# =========================
# Save CSV (simulation input)
# =========================
profile_all.to_csv(CSV_OUT, index=False)
print(f"[OK] Saved: {CSV_OUT.resolve()}")

# =========================
# Plot Fig 3.2
# =========================
x_hours = profile_all["start_minute"].values / 60.0

plt.figure(figsize=(10, 5))
if PLOT_WEEKDAY_WEEKEND:
    plt.plot(x_hours, profile_weekday["rate_per_hour"].values, label="Weekday")
    plt.plot(x_hours, profile_weekend["rate_per_hour"].values, label="Weekend")
    plt.plot(x_hours, profile_all["rate_per_hour"].values, label="All days", linestyle="--")
    plt.legend()
else:
    plt.plot(x_hours, profile_all["rate_per_hour"].values)

plt.title(r"Fig 3.2 Driver supply profile: driver login rate $\lambda_d(t)$")
plt.xlabel("Time of day (hours)")
plt.ylabel("Login rate (drivers/hour)")
plt.xticks(np.arange(0, 24.01, 2))
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(FIG_OUT, dpi=200)
plt.close()
print(f"[OK] Saved: {FIG_OUT.resolve()}")


# =========================
# Optional: Poisson check via Var/Mean by bin
# =========================
if MAKE_POISSON_CHECK:
    # Daily counts per bin (filled with 0)
    days = pd.Index(sorted(df["date"].unique()))
    daily_bin = (
        df.groupby(["date", "bin"])
        .size()
        .rename("count")
        .reset_index()
    )
    full_index = pd.MultiIndex.from_product([days, range(BINS_PER_DAY)], names=["date", "bin"])
    daily_full = (
        daily_bin.set_index(["date", "bin"])
        .reindex(full_index, fill_value=0)
        .reset_index()
    )

    stats = (
        daily_full.groupby("bin")["count"]
        .agg(mean="mean", var="var")
        .reset_index()
    )
    stats["var_over_mean"] = stats["var"] / stats["mean"].replace(0, np.nan)
    stats["start_minute"] = stats["bin"] * BIN_MINUTES
    stats["end_minute"] = (stats["bin"] + 1) * BIN_MINUTES
    stats["n_days"] = len(days)

    # Save CSV
    stats.to_csv(VOM_CSV_OUT, index=False)
    print(f"[OK] Saved: {VOM_CSV_OUT.resolve()}")

    # Plot
    x_hours2 = stats["start_minute"].values / 60.0
    plt.figure(figsize=(10, 4))
    plt.plot(x_hours2, stats["var_over_mean"].values)
    plt.axhline(1.0, linestyle="--", linewidth=1)
    plt.title("Appendix Fig A.1: Var/Mean by 15-min bin (Poisson check)")
    plt.xlabel("Time of day (hours)")
    plt.ylabel("Var/Mean")
    plt.xticks(np.arange(0, 24.01, 2))
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(VOM_FIG_OUT, dpi=200)
    plt.close()
    print(f"[OK] Saved: {VOM_FIG_OUT.resolve()}")