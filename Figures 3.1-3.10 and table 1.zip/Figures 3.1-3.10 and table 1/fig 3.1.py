import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

# =========================
# Config
# =========================
INPUT = Path("riders_clean.csv")
FIG_OUT = Path("fig_3_1_lambda_r.png")
CSV_OUT = Path("lambda_r_15min.csv")

BIN_MINUTES = 15
BINS_PER_DAY = 24 * 60 // BIN_MINUTES  # 96
PLOT_WEEKDAY_WEEKEND = True  # Set to False to plot only one overall curve


# =========================
# Load
# =========================
df = pd.read_csv(INPUT)

if "request_datetime" not in df.columns:
    raise ValueError("Column 'request_datetime' not found in riders_clean.csv.")

df["request_datetime"] = pd.to_datetime(df["request_datetime"], errors="coerce")
df = df.dropna(subset=["request_datetime"]).copy()

# Date + binning (0..95)
df["date"] = df["request_datetime"].dt.date
minutes = df["request_datetime"].dt.hour * 60 + df["request_datetime"].dt.minute
df["bin"] = (minutes // BIN_MINUTES).astype(int)

# Keep only valid bins
df = df[(df["bin"] >= 0) & (df["bin"] < BINS_PER_DAY)].copy()

# =========================
# Helper: compute mean counts per bin across days
# =========================
def mean_profile(sub: pd.DataFrame) -> pd.DataFrame:
    days = pd.Index(sorted(sub["date"].unique()))
    n_days = len(days)

    # Count trips per day per bin
    daily_bin = (
        sub.groupby(["date", "bin"])
        .size()
        .rename("count")
        .reset_index()
    )

    # Fill missing bins so that each day has bins 0..95
    # Bins with no requests are recorded as 0
    full_index = pd.MultiIndex.from_product([days, range(BINS_PER_DAY)], names=["date", "bin"])
    daily_full = (
        daily_bin.set_index(["date", "bin"])
        .reindex(full_index, fill_value=0)
        .reset_index()
    )

    # Compute average across days
    prof = (
        daily_full.groupby("bin")["count"]
        .mean()
        .rename("mean_count")
        .reset_index()
    )

    prof["start_minute"] = prof["bin"] * BIN_MINUTES
    prof["end_minute"] = (prof["bin"] + 1) * BIN_MINUTES
    prof["rate_per_hour"] = prof["mean_count"] / (BIN_MINUTES / 60.0)  # mean_count / 0.25
    prof["n_days"] = n_days

    # Arrange column order
    prof = prof[["bin", "start_minute", "end_minute", "mean_count", "rate_per_hour", "n_days"]]
    return prof


# =========================
# Compute profiles
# =========================
profile_all = mean_profile(df)

if PLOT_WEEKDAY_WEEKEND:
    df["is_weekend"] = df["request_datetime"].dt.weekday >= 5  # 5=Sat, 6=Sun
    profile_weekday = mean_profile(df[~df["is_weekend"]])
    profile_weekend = mean_profile(df[df["is_weekend"]])

# =========================
# Save CSV (overall)
# =========================
profile_all.to_csv(CSV_OUT, index=False)
print(f"[OK] Saved: {CSV_OUT.resolve()}")

# =========================
# Plot
# =========================
x = profile_all["bin"].values
x_labels_minutes = profile_all["start_minute"].values
x_hours = x_labels_minutes / 60.0

plt.figure(figsize=(10, 5))

if PLOT_WEEKDAY_WEEKEND:
    plt.plot(x_hours, profile_weekday["rate_per_hour"].values, label="Weekday")
    plt.plot(x_hours, profile_weekend["rate_per_hour"].values, label="Weekend")
    plt.plot(x_hours, profile_all["rate_per_hour"].values, label="All days", linestyle="--")
    plt.legend()
else:
    plt.plot(x_hours, profile_all["rate_per_hour"].values)

plt.title(r"Fig 3.1 Rider demand profile: piecewise arrival rate $\lambda_r(t)$")
plt.xlabel("Time of day (hours)")
plt.ylabel("Arrival rate (requests/hour)")

# X-axis ticks: one tick every 2 hours
ticks = np.arange(0, 24.01, 2)
plt.xticks(ticks)

plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(FIG_OUT, dpi=200)
plt.close()

print(f"[OK] Saved: {FIG_OUT.resolve()}")