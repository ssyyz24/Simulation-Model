import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# =====================
# Load data
# =====================
df = pd.read_csv("drivers_clean.csv")


df = df.dropna(subset=["initial_x", "initial_y"])

x = df["initial_x"]
y = df["initial_y"]

# =====================
# Heatmap grid
# =====================
GRID_SIZE = 50   # 50x50 grid

heatmap, xedges, yedges = np.histogram2d(
    x,
    y,
    bins=GRID_SIZE,
    range=[[0,20],[0,20]]
)

# =====================
# Plot
# =====================
plt.figure(figsize=(6.5,6))

plt.imshow(
    heatmap.T,
    origin="lower",
    extent=[0,20,0,20],
    aspect="equal"
)

plt.colorbar(label="Driver count per grid cell")

plt.title("Fig 3.5 Driver initial locations heatmap")
plt.xlabel("x (miles)")
plt.ylabel("y (miles)")

plt.tight_layout()

plt.savefig("fig_3_5_driver_initial_heatmap.png", dpi=300)

plt.close()

print("Fig 3.5 saved: fig_3_5_driver_initial_heatmap.png")