import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ======================
# Config
# ======================
INPUT_FILE = "riders_clean.csv"
GRID_SIZE = 5
CITY_SIZE = 20
ZONE_WIDTH = CITY_SIZE / GRID_SIZE

FIG_OUT = "fig_3_6_OD_matrix_5x5.png"
CSV_OUT = "OD_matrix_5x5.csv"

# ======================
# Load data
# ======================
df = pd.read_csv(INPUT_FILE)

# Use completed trips only
df = df[df["status"] == "dropped-off"]

df = df.dropna(subset=[
    "pickup_x", "pickup_y",
    "dropoff_x", "dropoff_y"
])

# ======================
# Compute zones
# ======================
df["origin_zone_x"] = (df["pickup_x"] // ZONE_WIDTH).astype(int)
df["origin_zone_y"] = (df["pickup_y"] // ZONE_WIDTH).astype(int)

df["dest_zone_x"] = (df["dropoff_x"] // ZONE_WIDTH).astype(int)
df["dest_zone_y"] = (df["dropoff_y"] // ZONE_WIDTH).astype(int)

# Convert 2D zones into a single index (0..24)
df["origin_zone"] = df["origin_zone_y"] * GRID_SIZE + df["origin_zone_x"]
df["dest_zone"] = df["dest_zone_y"] * GRID_SIZE + df["dest_zone_x"]

# ======================
# OD count matrix
# ======================
od_counts = pd.crosstab(
    df["origin_zone"],
    df["dest_zone"]
)

# Ensure a 25x25 matrix
od_counts = od_counts.reindex(
    index=range(GRID_SIZE**2),
    columns=range(GRID_SIZE**2),
    fill_value=0
)

# ======================
# Convert to probability
# ======================
total_trips = od_counts.values.sum()
od_prob = od_counts / total_trips

# ======================
# Save CSV
# ======================
rows = []

for i in range(GRID_SIZE**2):
    for j in range(GRID_SIZE**2):

        rows.append({
            "origin_zone": i,
            "dest_zone": j,
            "count": int(od_counts.iloc[i,j]),
            "prob": float(od_prob.iloc[i,j])
        })

od_df = pd.DataFrame(rows)

od_df.to_csv(CSV_OUT, index=False)

print("Saved:", CSV_OUT)

# ======================
# Plot heatmap
# ======================
plt.figure(figsize=(7,6))

plt.imshow(
    od_counts,
    origin="lower",
    aspect="auto"
)

plt.colorbar(label="Trip count")

plt.title("Fig 3.6 OD structure: zone-to-zone flow matrix")
plt.xlabel("Destination zone")
plt.ylabel("Origin zone")

plt.tight_layout()

plt.savefig(FIG_OUT, dpi=300)

plt.close()

print("Saved:", FIG_OUT)